// Backend API Configuration
// Replace this with your actual Render backend URL after deploying the backend
window.BACKEND_URL = 'https://interim-assesment-lil-chrisp.onrender.com';

